// vim:syntax=javascript:filetype=javascript

;(function(exports) {
  if(typeof(exports.Zendesk) == 'undefined') {
    exports.Zendesk = {};
  }

  // container class
  var jsLogin = document.getElementById("zendesk-js-login"),
    // inline templates
    baseHtml = "\n\n<span>&nbsp;</span>\n\n<script defer=\"defer\" src=\"https://p5.zdassets.com/assets/Placeholders-9b3ff158b9ad6d76b7ec263eea55e562.js\"></script>\n<script defer=\"defer\" src=\"https://p5.zdassets.com/assets/history-e0344e4374ec9e98271985160a99daeb.js\"></script>\n\n<div id=\"sso-container\"></div>\n",
    jsLoginHtml = "<div class=\"login help_center\">\n  <div class=\"interface outer\">\n    \n    <h2 class=\"title\">\n      Sign in to Voyager Support\n    </h2>\n\n    <div class=\"interface inner\">\n      <div class=\"services external\" id=\"zendesk-js-login-external\">\n        <a href=\"https://voyagersearch.zendesk.com/access/request_oauth?profile=twitter_readonly&amp;return_to=https%3A%2F%2Fvoyagersearch.zendesk.com%2Fhc%2Fen-us&amp;scheme=https\" class=\"service twitter\" target=\"_top\">\n          <span class=\"logo\">&#xf309;</span>\n          Sign in with Twitter\n</a>\n        <a href=\"https://voyagersearch.zendesk.com/access/request_oauth?profile=facebook&amp;return_to=https%3A%2F%2Fvoyagersearch.zendesk.com%2Fhc%2Fen-us&amp;scheme=https\" class=\"service facebook\" id=\"zd_facebook_login_link\" style=\"display: none\" target=\"_top\">\n          <span class=\"logo\">&#xf30c;</span>\n          Sign in with Facebook\n</a>\n        <a href=\"https://accounts.google.com/o/oauth2/auth?client_id=749019779237-4696326jponq05n0k8fiaupk1iac0vpd.apps.googleusercontent.com&amp;redirect_uri=https%3A%2F%2Fgoogle.zendesk.com%2Fauth%2Fgoogle&amp;response_type=code&amp;scope=email&amp;state=eyJ0eXAiOiJKV1QiLCJhbGciOiJIUzI1NiJ9.eyJyZXR1cm5fdG8iOiJodHRwczovL3ZveWFnZXJzZWFyY2guemVuZGVzay5jb20vaGMvZW4tdXMiLCJzdWJkb21haW4iOiJ2b3lhZ2Vyc2VhcmNoIiwic3RhdGUiOiJjMGRhMTQ5YjViNWEyZDk1OWMwOGNlZDM5Y2RmMWRiMjFmZGJiZDIyIn0.LRVFzwRdtETwh7qagz2gJGtiE_WiMFgpHM8t7FnSyOw\" class=\"service google\" style=\"display: none\" target=\"_top\">\n          <span class=\"logo\">&#xf30f;</span>\n          Sign in with Google\n</a></div>\n      <div class=\"separator\" id=\"zendesk-js-login-separator\">\n        or\n</div>\n      <div class=\"services internal\">\n        <form accept-charset=\"UTF-8\" action=\"https://voyagersearch.zendesk.com/access/login\" autocomplete=\"off\" class=\"\" id=\"login-form\" method=\"post\"><div style=\"margin:0;padding:0;display:inline\"><input name=\"utf8\" type=\"hidden\" value=\"&#x2713;\" /><input name=\"authenticity_token\" type=\"hidden\" value=\"null\" /></div>\n          \n          \n          <div class=\"credentials\">\n            <input autocomplete=\"on\" autofocus=\"autofocus\" id=\"user_email\" name=\"user[email]\" placeholder=\"Email\" size=\"30\" type=\"email\" />\n            <input autocomplete=\"off\" id=\"user_password\" name=\"user[password]\" placeholder=\"Password\" size=\"30\" type=\"password\" />\n          </div>\n\n          <div class=\"remember\">\n            <input id=\"remember_me\" name=\"remember_me\" type=\"checkbox\" value=\"1\" />\n            <label for=\"remember_me\">Stay signed in</label>\n          </div>\n\n          <div class=\"clear\"></div>\n\n          <input class=\"button primary\" name=\"commit\" type=\"submit\" value=\"Sign in\" />\n</form>\n        <a href=\"/hc\" class=\"cancel\">Cancel</a>\n\n        <div class=\"clear\"></div>\n      </div>\n\n      <div class=\"clear\"></div>\n\n      <div class=\"assistance\">\n        <div class=\"roles\" id=\"zendesk-js-login-roles\">\n            <a href=\"#\" class=\"multiple_options role agent\">\n              I am an Agent\n</a>\n            <a href=\"#\" class=\"multiple_options role end_user\" style=\"display: none\">\n              I am a Customer\n</a>        </div>\n\n        <div class=\"forgot_password\" id=\"zendesk-js-forgot-password\">\n          <a href=\"#\" onclick=\"Zendesk.SSO.passwordReset(); return false;\">Forgot my password</a>\n        </div>\n      </div>\n      <div class=\"clear\"></div>\n    </div>\n  </div>\n\n    <div class=\"footnotes\">\n        <div class=\"sign_up question\">\n          New to Voyager Support?\n          <a href=\"#\" onclick=\"Zendesk.SSO.registration(); return false;\">Sign up</a>\n        </div>\n\n        <p class=\"get_password question\">\n          Have you emailed us?\n          <a href=\"#\" onclick=\"Zendesk.SSO.passwordReset(); return false;\">Get a password</a>\n        </p>\n\n        <p>If you've communicated with our support staff through email previously, you're already registered. <br /> You probably don't have a password yet, though.</p>\n    </div>\n</div>\n\n<script onload=\"Zendesk.SSO.initLoginServiceManager()\" src=\"https://p5.zdassets.com/assets/zendesk/auth/v1/login_service_manager-e84271d4c7e002d942b671a1e872c95e.js\"></script>\n\n",
    jsPasswordResetHtml = "\n<h2 class=\"title\">Please set me up with a new password</h2>\n\n<form accept-charset=\"UTF-8\" action=\"https://voyagersearch.zendesk.com/access/help\" class=\"box box_form\" id=\"password-reset-form\" method=\"post\"><div style=\"margin:0;padding:0;display:inline\"><input name=\"utf8\" type=\"hidden\" value=\"&#x2713;\" /><input name=\"authenticity_token\" type=\"hidden\" value=\"null\" /></div>\n  \n  \n  <p>Submit your email address, and we'll send you an email that sets you up with a new password.</p>\n\n  <fieldset>\n    <label for=\"email\">Your email</label>\n    <input id=\"email\" name=\"email\" type=\"text\" />\n  </fieldset>\n\n  <div class=\"controls\">\n    <input class=\"button primary\" name=\"commit\" type=\"submit\" value=\"Submit\" />\n    <a href=\"#\" onclick=\"Zendesk.SSO.login(); return false;\">cancel</a>\n  </div>\n</form>",
    jsRegistrationHtml = "\n\n<h2 class=\"title\">Sign up to Voyager Support</h2>\n\n<form accept-charset=\"UTF-8\" action=\"https://voyagersearch.zendesk.com/registration/register\" class=\"box box_form\" id=\"registration-form\" method=\"post\"><div style=\"margin:0;padding:0;display:inline\"><input name=\"utf8\" type=\"hidden\" value=\"&#x2713;\" /><input name=\"authenticity_token\" type=\"hidden\" value=\"null\" /></div>\n  <p>Please fill out this form, and we'll send you a welcome email to verify your email address and log you in.</p>\n\n  <fieldset>\n    \n    \n\n    <label for=\"user_name\">Your full name <super>*</super></label>\n    <input id=\"user_name\" name=\"user[name]\" size=\"30\" type=\"text\" />\n\n    <label for=\"user_email\">Your email <super>*</super></label>\n    <input id=\"user_email\" name=\"user[email]\" size=\"30\" type=\"text\" />\n\n      <label for=\"user_twitter_screen_name\">Your Twitter</label>\n      <input id=\"user_twitter_screen_name\" name=\"user[twitter_screen_name]\" size=\"30\" type=\"text\" />\n\n    <div id=\"recaptcha_widget\">\n  <div id=\"recaptcha_data\">\n    <div id=\"recaptcha_image\"></div>\n    <ul>\n      <li><a href=\"javascript:Recaptcha.reload()\">Different text please</a></li>\n      <li>\n        <a id=\"recaptcha_switch_audio_btn\" class=\"recaptcha_only_if_image\" href=\"javascript:Recaptcha.switch_type('audio');\" title=\"Get an audio challenge\">I want audio instead</a>\n        <a id=\"recaptcha_switch_img_btn\" class=\"recaptcha_only_if_audio\" href=\"javascript:Recaptcha.switch_type('image');\" title=\"Get a visual challenge\">I want an image instead</a>\n      </li>\n    </ul>\n  </div>\n</div>\n\n<script type=\"text/javascript\">\n  var RecaptchaOptions = {\"theme\": \"custom\", \"custom_translations\": {\"visual_challenge\": \"Get a visual challenge\", \"audio_challenge\": \"Get an audio challenge\", \"refresh_btn\": \"Get a new challenge\", \"instructions_visual\": \"Type the text:\", \"instructions_audio\": \"Type what you hear:\", \"help_btn\": \"Help\", \"play_again\": \"Play sound again\", \"cant_hear_this\": \"Download sound as MP3\", \"incorrect_try_again\": \"Incorrect. Try again.\", \"image_alt_text\": \"reCAPTCHA challenge image\", \"privacy_and_terms\": \"Privacy & Terms\"}};\n</script>\n          <div id=\"dynamic_recaptcha\"></div>\n          <script type=\"text/javascript\">\n            var rc_script_tag = document.createElement('script'),\n                rc_init_func = function(){Recaptcha.create(\"6Lej0-kSAAAAAGXW70Y0j5emfJYBw1Fyg0Ftpuo7\", document.getElementById(\"dynamic_recaptcha\"),RecaptchaOptions);}\n            rc_script_tag.src = \"https://www.google.com/recaptcha/api/js/recaptcha_ajax.js\";\n            rc_script_tag.type = 'text/javascript';\n            rc_script_tag.onload = function(){rc_init_func.call();};\n            rc_script_tag.onreadystatechange = function(){\n              if (rc_script_tag.readyState == 'loaded' || rc_script_tag.readyState == 'complete') {rc_init_func.call();}\n            };\n            (document.getElementsByTagName('head')[0] || document.getElementsByTagName('body')[0]).appendChild(rc_script_tag);\n          </script>\n\n\n<label for=\"recaptcha_response_field\">Please verify text <super>*</super></label>\n<input id=\"recaptcha_response_field\" name=\"recaptcha_response_field\" type=\"text\" />\n\n  </fieldset>\n\n  <div class=\"controls\">\n    <input class=\"button primary\" disable_with_ignored=\"Signing up&hellip;\" name=\"commit\" type=\"submit\" value=\"Sign up\" />\n    <a href=\"#\" onclick=\"Zendesk.SSO.login(); return false;\">cancel</a>\n  </div>\n</form>",
    jsOneTimePasswordHtml = "<h2 class=\"title\">\n  Two-factor authentication\n</h2>\n\n<form accept-charset=\"UTF-8\" action=\"https://voyagersearch.zendesk.com/auth/one_time_password\" autocomplete=\"off\" class=\"box box_form\" id=\"one-time-password-form\" method=\"post\"><div style=\"margin:0;padding:0;display:inline\"><input name=\"utf8\" type=\"hidden\" value=\"&#x2713;\" /><input name=\"authenticity_token\" type=\"hidden\" value=\"null\" /></div>\n  <fieldset>\n    <label for=\"password\">Authentication Code</label>\n    <input autofocus=\"autofocus\" id=\"password\" name=\"password\" type=\"text\" />\n  </fieldset>\n\n  <div class=\"controls\">\n    <input class=\"button primary\" name=\"commit\" type=\"submit\" value=\"Verify\" />\n    <a href=\"#\" onclick=\"Zendesk.SSO.login(); return false;\">Cancel</a>\n  </div>\n\n  <input id=\"remember_me\" name=\"remember_me\" type=\"hidden\" />\n</form>\n<div class=\"footnotes\">\n  <h3 class=\"footnote-title\">Don't have your phone?</h3>\n\n  <span>You can always enter a recovery code in the box above.</span>\n\n</div>\n",




    // DOM variables
    container, returnTo, failureReturnTo, returnToAfterUserCreated,
    // state
    currentState, currentForm, poppedState = false, initialState = true,
    // security
    authenticityToken;

  // window.onpopstate callback
  function popStateEvent(event) {
    poppedState = true;

    if(event.state != null) {
      chooseForm(event.state.form);
    } else {
      initForm();
    }

    poppedState = false;
  };

  function chooseForm(form) {
    switch(form) {
      case 'password-reset':
        initPasswordReset();
        break;
      case 'register':
        initRegistration();
        break;
      case 'email-verification':
        initEmailVerification() || initLogin();
        break;
      case 'password-set':
        initPasswordSet() || initLogin();
        break;
      case 'password-change':
        initPasswordChange() || initLogin();
        break;
      case 'successful-registration':
        initSuccessfulRegistration() || initLogin();
        break;
      case 'one-time-password':
        initOneTimePassword();
        break;
      default:
        initLogin();
    }
  };

  function setState(state) {
    if(currentState != state) {
      // if the user didn't hit the back button and we're not already
      // on the state, then push it into the history
      if(!poppedState && window.location.hash.substr(1) != state) {
        hash = '#' + state;
        window.history.pushState({ 'form': state }, null, hash);
      }

      currentState = state;

      return true;
    }

    // We didn't actually change forms
    return false;
  };

  function setFormAuthenticityToken() {
    if(!currentForm)
      return;

    var hiddenInput = currentForm.children[0];

    // Rails always has 'hidden' input div first
    authenticityTokenInput = hiddenInput.children.namedItem('authenticity_token');
    // if it doesn't exist, something is wrong
    authenticityTokenInput.value = authenticityToken;
  }

  function setForm(html, id) {
    if(!initialState) {
      // hide the flash
      var flash, flashes = document.querySelectorAll('div.flash');

      for(var i = 0; i < flashes.length; i++) {
        flash = flashes[i];
        flash.parentNode.removeChild(flash);
      }
    }

    container.innerHTML = html;
    initialState = false;

    if(id) {
      currentForm = document.getElementById(id);

      setFormAuthenticityToken();

      if (id === 'registration-form' && returnToAfterUserCreated) {
        insertReturnToAfterUserCreated(currentForm.children[0]);
      } else {
        insertReturnTo(currentForm.children[0]);
      }

      container.setAttribute('class', id);
    }

    loadScripts(container);
  }

  function loadScripts(element) {
    var script, scripts = element.getElementsByTagName('script');
    var length = scripts.length;

    for(var i = 0; i < length; i++) {
      script = scripts[i];

      if(script.src == '') {
        window.eval(script.innerHTML);
      } else {
        var newScript = document.createElement('script');

        newScript.src = script.src;
        newScript.onload = script.onload;
        newScript.onreadystatechange = function() {
          if(newScript.readyState == 'complete') {
            (new Function(script.onload))();
          }
        };

        // IE 8 doesn't have document.head
        document.getElementsByTagName('head')[0].appendChild(newScript);
      }
    }
  }

  function insertReturnToAfterUserCreated(element) {
    if (returnToAfterUserCreated) {
      element.appendChild(returnToAfterUserCreated);
    }

    insertFailureReturnTo(element);
  }

  function insertReturnTo(element) {
    if (returnTo) {
      element.appendChild(returnTo);
    }

    insertFailureReturnTo(element);
  }

  function insertFailureReturnTo(element) {
    failureReturnTo.value = window.location.href;
    element.appendChild(failureReturnTo);
  }

  function initRegistration() {
    if(setState('register')) {
      setForm(jsRegistrationHtml, 'registration-form');
    }
  };

  function initOneTimePassword() {
    if(setState('one-time-password')) {
      setForm(jsOneTimePasswordHtml, 'one-time-password-form');
    }
  };

  function initPasswordReset() {
    if (setState('password-reset')) {
      setForm(jsPasswordResetHtml, 'password-reset-form');
    }
  };

  // Password set and email verification rely on a token to fill in the correct user
  // If we don't have a token, we can't show the correct form
  // Note: This isn't security, it's just so we don't show a form that doesn't do anything
  function initEmailVerification() {
    if(typeof(jsEmailVerificationHtml) == 'undefined')
      return false;

    if(setState('email-verification')) {
      setForm(jsEmailVerificationHtml, 'email-verification-form');
    }

    return true;
  };

  function initPasswordSet() {
    if(typeof(jsPasswordSetHtml) == 'undefined')
      return false;

    if(setState('password-set')) {
      setForm(jsPasswordSetHtml, 'password-set-form');
    }

    return true;
  };

  // Password change and successful registration require a logged in user
  // If we don't have a current user, we can't show the correct form
  // Note: This isn't security, it's just so we don't show a form that doesn't do anything
  function initPasswordChange() {
    if(typeof(jsPasswordChangeHtml) == 'undefined')
      return false;

    if (setState('password-change')) {
      setForm(jsPasswordChangeHtml, 'password-change-form');
    }

    return true;
  };

  function initSuccessfulRegistration() {
    if(typeof(jsSuccessfulRegistrationHtml) == 'undefined')
      return false;

    if(setState('successful-registration')) {
      setForm(jsSuccessfulRegistrationHtml);
    }

    return true;
  };

  function initLogin() {
    if(setState('login')) {
      setForm(jsLoginHtml, 'login-form');
    }
  };

  function initForm() {
    chooseForm(window.location.hash.substr(1));
  };

  exports.Zendesk.SSO = {
    init: function(settings) {
      settings = settings || {};
      agentOnly = settings.agentOnly || false;

      jsLogin.innerHTML = baseHtml;

      loadScripts(jsLogin);

      container = document.getElementById('sso-container');

      window.onpopstate = popStateEvent;

      if (settings.returnTo) {
        Zendesk.SSO.setReturnTo(settings.returnTo);
      }

      if (settings.returnToAfterUserCreated) {
        Zendesk.SSO.setReturnToAfterUserCreated(settings.returnToAfterUserCreated);
      }

      failureReturnTo = document.createElement('input');
      failureReturnTo.type = 'hidden';
      failureReturnTo.name = 'return_to_on_failure';

      if(settings.authenticityToken) {
        authenticityToken = settings.authenticityToken;
      } else {
        fetchTokenFromAuthDomain('https://voyagersearch.zendesk.com/auth/v1/login/token_proxy', function(token) {
          authenticityToken = token;
          setFormAuthenticityToken();
        });
      }
    },

    login: initLogin,
    passwordReset: initPasswordReset,
    registration: initRegistration,
    emailVerification: initEmailVerification,
    passwordSet: initPasswordSet,
    passwordChange: initPasswordChange,
    successfulRegistration: initSuccessfulRegistration,
    oneTimePassword: initOneTimePassword,
    render: initForm,
    secureUrl: 'https://voyagersearch.zendesk.com',

    initLoginServiceManager: function() {
      var settings = {"agent_only":false,"is_end_user_password_change_visible":true,"services":{"agent":{"google":false,"twitter":true,"facebook":false},"end_user":{"google":false,"twitter":true,"facebook":false}}};

      if(agentOnly)
        settings.agentOnly = agentOnly;

      new Zendesk.LoginServiceManager.init(settings);
      if (window.self !== window.top)  {
        var facebookLoginLink = document.getElementById('zd_facebook_login_link');
        if (facebookLoginLink) {
          facebookLoginLink.setAttribute('href', facebookLoginLink.getAttribute('href') + '&iframe=true');
        }
      }
    },

    setReturnToAfterUserCreated: function(url) {
      returnToAfterUserCreated = document.createElement('input');
      returnToAfterUserCreated.type = 'hidden';
      returnToAfterUserCreated.name = 'return_to';
      returnToAfterUserCreated.value = url;
    },

    setReturnTo: function(newReturnTo) {
      returnTo = document.createElement('input');
      returnTo.type = 'hidden';
      returnTo.name = 'return_to';
      returnTo.value = newReturnTo;
    }
  };

  (function() {
    var timer, frameUrl;

    frameUrl = 'https://voyagersearch.zendesk.com';

    var onToken = function(token){};
    var frame = document.createElement('iframe');
    var head = document.getElementsByTagName('body')[0];

    frame.setAttribute('style', 'position: absolute; left: -9999px; width: 1px; height: 1px;');

    function addEvent(elm, evt, cb) {
      if (elm.addEventListener) {
        elm.addEventListener(evt, cb, false);
      } else if (elm.attachEvent) {
        elm.attachEvent('on'+evt, cb);
      }
    }

    function removeEvent(elm, evt, cb) {
      if (elm.removeEventListener) {
        elm.removeEventListener(evt, cb, false);
      } else if (elm.detachEvent) {
        elm.detachEvent('on'+evt, cb);
      }
    }

    function onMessage(e) {
      var data = {};

      try {
        data = JSON.parse(e.data);
      } catch(e) {}

      if (data.name === 'token') {
        clearInterval(timer);
        onToken(data.token);

        frame.parentNode.removeChild(frame);
        removeEvent(window, 'message', onMessage);
      }
    }

    function requestToken() {
      var destination = frame.contentWindow;
      var data = { name: 'token' };
      if (destination && destination.postMessage) {
        destination.postMessage(JSON.stringify(data), frameUrl);
      }
    }

    addEvent(frame, 'load', function() {
      timer = setInterval(requestToken, 500);
      requestToken();
    });

    addEvent(window, 'message', onMessage);

    window.fetchTokenFromAuthDomain = function(src, cb) {
      frame.src = src;
      onToken = cb;
      head.appendChild(frame);
    };
  }).call(this);
}(this));
